package com.com470.seleniumMercuryApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeleniumMercuryAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeleniumMercuryAppApplication.class, args);
	}

}
