package com.com470.seleniumMercuryApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeleniumMercuryAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
